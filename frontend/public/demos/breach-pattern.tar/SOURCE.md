# Source

Rhino Security Labs' CloudGoat scenario cloud_breach_s3: a deliberately vulnerable-by-design AWS lab. Its attack path matches the one publicly reported for the 2019 Capital One breach. It is not Capital One's code.

- Repository: https://github.com/RhinoSecurityLabs/cloudgoat
- Commit: 63c65bd26edc6919499adfa20b176c450e35c33c
- License: BSD-3-Clause
- Files: the .tf files under cloudgoat/scenarios/aws/cloud_breach_s3/terraform, unchanged.

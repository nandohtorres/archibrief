# Source

The Federal Election Commission's custom AWS infrastructure: its Aurora database clusters and their network (last changed in 2020).

- Repository: https://github.com/fecgov/fec-infrastructure
- Commit: bd6fbd5ca00e3927b0d2ce0fd543ec9395315edd
- License: US Government work (public domain in the US); see LICENSE.md
- Files: the .tf files under terraform, unchanged.

locals {
  rate_limit_content = {
    APPLICATION_JSON = <<EOT
{
    "issue": [
        {
            "code": "throttled",
            "details": {
                "text": "Requests from this IP are currently throttled due to exceeding the limit. Try again in 5 minutes."
            },
            "severity": "error"
        }
    ],
    "resourceType": "OperationOutcome"
}
EOT
    TEXT_HTML        = <<EOT
<html>
  <p>Requests from this IP are currently throttled due to exceeding the limit. Try again in 5 minutes.</p>
</html>
EOT
    TEXT_PLAIN       = "Requests from this IP are currently throttled due to exceeding the limit. Try again in 5 minutes."
  }
}

resource "aws_wafv2_web_acl" "this" {
  name  = var.name
  scope = var.scope

  default_action {
    allow {}
  }

  custom_response_body {
    key          = "rate-limit-exceeded"
    content      = local.rate_limit_content[var.content_type]
    content_type = var.content_type
  }

  rule {
    name     = "us-only"
    priority = 1

    action {
      block {}
    }

    statement {
      not_statement {
        statement {
          geo_match_statement {
            country_codes = ["PR", "US", "VI"]
          }
        }
      }
    }

    visibility_config {
      cloudwatch_metrics_enabled = true
      metric_name                = "${var.name}-us-only"
      sampled_requests_enabled   = false
    }
  }

  dynamic "rule" {
    for_each = length(var.ip_sets) > 0 ? [1] : []

    content {
      name     = "ip-sets"
      priority = 2

      action {
        block {}
      }

      statement {
        not_statement {
          statement {
            or_statement {
              dynamic "statement" {
                for_each = var.ip_sets
                iterator = ip_set
                content {
                  ip_set_reference_statement {
                    arn = ip_set.value
                  }
                }
              }
            }
          }
        }
      }

      visibility_config {
        cloudwatch_metrics_enabled = true
        metric_name                = "${var.name}-ip-sets"
        sampled_requests_enabled   = false
      }
    }
  }

  rule {
    name     = "aws-common"
    priority = 3

    override_action {
      none {}
    }

    statement {
      managed_rule_group_statement {
        name        = "AWSManagedRulesCommonRuleSet"
        vendor_name = "AWS"

        # Override for size requirements of requests, this is set at 8kb which is too small for some acceptable requests
        rule_action_override {
          name = "SizeRestrictions_BODY"
          action_to_use {
            count {}
          }
        }

        # Override for XSS block on request body, DPC team sends HTML blocks in requests to certain endpoints
        dynamic "rule_action_override" {
          for_each = var.app == "dpc" ? ["apply"] : []
          content {
            name = "CrossSiteScripting_BODY"
            action_to_use {
              count {}
            }
          }
        }

        # Override for requests lacking a User-Agent header, as most BCDA requests are automated and lack them
        dynamic "rule_action_override" {
          for_each = var.app == "bcda" ? ["apply"] : []
          content {
            name = "NoUserAgent_HEADER"
            action_to_use {
              count {}
            }
          }
        }
      }
    }

    visibility_config {
      cloudwatch_metrics_enabled = true
      metric_name                = "${var.name}-aws-common"
      sampled_requests_enabled   = true
    }
  }

  rule {
    name     = "aws-ip-reputation"
    priority = 4

    override_action {
      none {}
    }

    statement {
      managed_rule_group_statement {
        name        = "AWSManagedRulesAmazonIpReputationList"
        vendor_name = "AWS"
      }
    }

    visibility_config {
      cloudwatch_metrics_enabled = true
      metric_name                = "${var.name}-aws-ip-reputation"
      sampled_requests_enabled   = true
    }
  }

  rule {
    name     = "aws-bad-inputs"
    priority = 5

    override_action {
      none {}
    }

    statement {
      managed_rule_group_statement {
        name        = "AWSManagedRulesKnownBadInputsRuleSet"
        vendor_name = "AWS"
      }
    }

    visibility_config {
      cloudwatch_metrics_enabled = true
      metric_name                = "${var.name}-aws-bad-inputs"
      sampled_requests_enabled   = true
    }
  }

  rule {
    name     = "rate-limit"
    priority = 6

    action {
      block {
        custom_response {
          custom_response_body_key = "rate-limit-exceeded"
          response_code            = 429
          response_header {
            name  = "Retry-After"
            value = "300"
          }
        }
      }
    }

    statement {
      rate_based_statement {
        limit              = var.rate_limit
        aggregate_key_type = "IP"
      }
    }

    visibility_config {
      cloudwatch_metrics_enabled = true
      metric_name                = "${var.name}-rate-limit"
      sampled_requests_enabled   = true
    }
  }

  visibility_config {
    cloudwatch_metrics_enabled = true
    metric_name                = var.name
    sampled_requests_enabled   = true
  }
}

resource "aws_wafv2_web_acl_association" "this" {
  count = var.associated_resource_arn != "" ? 1 : 0

  resource_arn = var.associated_resource_arn
  web_acl_arn  = aws_wafv2_web_acl.this.arn
}

##############
# Logging
#############

module "waf_log_group" {
  source = "../cloudwatch_log_group"

  # WAF log group names MUST be prefixed with "aws-waf-logs-"
  name       = "aws-waf-logs-${var.name}"
  env        = var.platform.env
  kms_key_id = var.platform.kms_alias_primary.target_key_arn
}

resource "aws_cloudwatch_log_resource_policy" "waf" {
  policy_name = "aws-waf-logs-${var.name}"
  policy_document = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Principal = {
          Service = "delivery.logs.amazonaws.com"
        }
        Action = [
          "logs:CreateLogStream",
          "logs:PutLogEvents"
        ]
        Resource = "${module.waf_log_group.this.arn}:*"
        Condition = {
          StringEquals = {
            "aws:SourceAccount" = var.platform.account_id
          }
        }
      }
    ]
  })
}

resource "aws_wafv2_web_acl_logging_configuration" "this" {
  log_destination_configs = [module.waf_log_group.this.arn]
  resource_arn            = aws_wafv2_web_acl.this.arn

  dynamic "logging_filter" {
    for_each = var.logging_filter != null ? [var.logging_filter] : []
    content {
      default_behavior = logging_filter.value.default_behavior

      dynamic "filter" {
        for_each = logging_filter.value.filters
        content {
          behavior    = filter.value.behavior
          requirement = filter.value.requirement

          dynamic "condition" {
            for_each = filter.value.conditions
            content {
              dynamic "action_condition" {
                for_each = condition.value.action_condition != "" ? [1] : []
                content {
                  action = condition.value.action_condition
                }
              }

              dynamic "label_name_condition" {
                for_each = condition.value.label_name_condition != "" ? [1] : []
                content {
                  label_name = condition.value.label_name_condition
                }
              }
            }
          }
        }
      }
    }
  }
}

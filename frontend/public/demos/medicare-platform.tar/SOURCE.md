# Source

The Centers for Medicare & Medicaid Services (CMS) platform for the AB2D, BCDA and DPC Medicare data APIs: the network, firewall, encryption-key, backup and access-log slice.

- Repository: https://github.com/CMSgov/cdap
- Commit: e3b284998d05d77660f6a734a11aa2b42de1f205
- License: CC0-1.0
- Files: the .tf files under terraform/services/020-vpc-network, terraform/services/security-groups, terraform/services/api-waf, terraform/services/kms-keys, terraform/services/backup-plan, terraform/services/bucket-access-logs, terraform/modules/vpc, terraform/modules/firewall, terraform/modules/platform, unchanged.

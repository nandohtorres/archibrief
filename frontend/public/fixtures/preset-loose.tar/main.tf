resource "aws_s3_bucket" "temp" {
  bucket = "loose-demo-temp"
}

resource "aws_s3_bucket" "data" {
  bucket = "complex-demo-data"
}

resource "aws_s3_bucket" "logs" {
  bucket = "complex-demo-logs"
}

resource "aws_s3_bucket_public_access_block" "logs" {
  bucket = aws_s3_bucket.logs.id
}

resource "aws_s3_bucket_server_side_encryption_configuration" "logs" {
  bucket = aws_s3_bucket.logs.id
  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm = "aws:kms"
    }
  }
}

resource "aws_db_instance" "primary" {
  identifier         = "complex-demo-db"
  engine             = "postgres"
  instance_class     = "db.r5.large"
  allocated_storage  = 100
  storage_encrypted  = false
  multi_az           = false
}

resource "aws_security_group" "web" {
  name = "complex-demo-web-sg"
  ingress {
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
}

resource "aws_ebs_volume" "data_volume" {
  availability_zone = "us-east-1a"
  size              = 50
  encrypted         = false
}

resource "aws_iam_policy" "broad" {
  name   = "complex-demo-broad-policy"
  policy = "{\"Version\": \"2012-10-17\", \"Statement\": [{\"Effect\": \"Allow\", \"Action\": \"*\", \"Resource\": \"*\"}]}"
}

resource "aws_iam_role" "app_role" {
  name = "complex-demo-app-role"
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect    = "Allow"
        Principal = { AWS = "arn:aws:iam::999999999999:root" }
        Action    = "sts:AssumeRole"
      }
    ]
  })
}

resource "aws_lambda_function" "processor" {
  function_name = "complex-demo-processor"
  handler       = "handler.handler"
  runtime       = "python3.12"
  environment {
    variables = {
      PAYMENT_API_KEY = "placeholder"
    }
  }
}

resource "aws_dynamodb_table" "sessions" {
  name         = "complex-demo-sessions"
  billing_mode = "PAY_PER_REQUEST"
  hash_key     = "session_id"
  attribute {
    name = "session_id"
    type = "S"
  }
}

resource "aws_subnet" "public" {
  vpc_id                  = "vpc-0123456789abcdef0"
  cidr_block              = "10.0.1.0/24"
  map_public_ip_on_launch = true
}

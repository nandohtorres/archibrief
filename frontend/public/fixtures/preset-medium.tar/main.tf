resource "aws_s3_bucket" "assets" {
  bucket = "medium-demo-assets"
}

resource "aws_s3_bucket_public_access_block" "assets" {
  bucket = aws_s3_bucket.assets.id
}

resource "aws_s3_bucket_server_side_encryption_configuration" "assets" {
  bucket = aws_s3_bucket.assets.id
  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm = "aws:kms"
    }
  }
}

resource "aws_db_instance" "db" {
  identifier        = "medium-demo-db"
  engine            = "postgres"
  instance_class    = "db.t3.small"
  allocated_storage = 20
  storage_encrypted = true
  multi_az          = false
}

resource "aws_security_group" "app" {
  name = "medium-demo-app-sg"
  ingress {
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = ["10.0.0.0/16"]
  }
}

resource "aws_lambda_function" "worker" {
  function_name                 = "medium-demo-worker"
  handler                       = "handler.handler"
  runtime                       = "python3.12"
  reserved_concurrent_executions = 5
}
